package com.example.clockedout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Timesheet : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timesheet)
    }
}